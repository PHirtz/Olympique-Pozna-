import{l as o,a as r}from"../chunks/DoAo2tbP.js";export{o as load_css,r as start};
